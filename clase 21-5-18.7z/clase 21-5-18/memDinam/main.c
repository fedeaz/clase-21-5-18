#include <stdio.h>
#include <stdlib.h>

int main()
{
    int* pNum;

    pNum = (int*) malloc(sizeof(int));

    if(pNum == NULL)
    {
        printf("No se pudo conseguir memoria. el programa finalizara\n\n");
        exit(1);
    }
        printf("ingrese un numero\n");
        scanf("%d", pNum);
    //*pNum = 5;

    printf("%d\n\n", *pNum);
    free(pNum);
    return 0;
}
