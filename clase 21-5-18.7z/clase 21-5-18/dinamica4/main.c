#include <stdio.h>
#include <stdlib.h>

typedef struct{
    int legajo;
    char nombre[20];
    float sueldo;
}eEmpleado;

void mostrarEmpleado(eEmpleado*);

eEmpleado* newEmpleado();

int main()
{
    eEmpleado* unEmpleado;
    unEmpleado = newEmpleado();
    if(unEmpleado == NULL)
    {
        printf("no se consiguio memoria :\n");
        system("pause");
        exit(1);
    }
    else
    {
        mostrarEmpleado(unEmpleado);
        unEmpleado->legajo = 1234
        unEmpleado->nombre

    }


    return 0;
}


void mostrarEmpleado(eEmpleado* emp)
{
    printf("%d %s %.2f\n", emp->legajo,emp->nombre,emp->sueldo);
}

eEmpleado* newEmpleado()
{
    eEmpleado* p;
    p= (eEmpleado*) malloc(sizeof(eEmpleado));
    if(p!=NULL)
    {
        p->legajo =0;
        strcpy(p->nombre, "");
        p->sueldo =0;
    }
    return p;
}
