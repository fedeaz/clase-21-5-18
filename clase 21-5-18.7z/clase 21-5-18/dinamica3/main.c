#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;
    int* vec;
    int* aux;

    vec= (int*) malloc(5* sizeof(int));
    if(vec==NULL)
    {
        printf("\n no se consiguio la memosria\n\n");
        system("pause");
        exit(1);
    }
    for(i =0;i<5;i++)
    {
        printf("ingrese un numero");
        scanf("%d",vec+i);
    }


    for(i =0;i<5;i++)
    {
        printf("%d",*(vec+i));
    }
    printf("\n\n");

    aux = (int*)realloc(vec, 10* sizeof(int));
    if(aux == NULL)
    {
      printf("\n no se consiguio la memosria\n\n");
        system("pause");
        exit(1);
    }
    else
    {
        vec= aux;

        for(i =0;i<5;i++)
    {
        printf("ingrese un numero");
        scanf("%d",vec+i);
    }


    for(i =0;i<5;i++)
    {
        printf("%d",*(vec+i));

    }
    printf("\n\n");
    }

    // achicar !
    //vec=(int*) realloc(vec,5*sizeof(int));

    free(vec);


    return 0;
}
